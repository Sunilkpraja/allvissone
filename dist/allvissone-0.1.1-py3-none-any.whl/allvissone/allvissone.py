def info():
    print("Welcome to Data Science Visualization Module.")
    print("-------------------------------")
    print("Your Data Science Visualization Module is Ready to use.")
    print("-------------------------------")